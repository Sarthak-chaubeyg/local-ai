/**
 * Network Module — API calls, streaming, model discovery.
 * All network requests go through Security.isSafeApiBase validation.
 * Rate limiting applied to discovery and send operations.
 *
 * 🔒 Key security improvement (M1): API key is NOT sent during initial
 * host probing. The probe sends an unauthenticated request first.
 * The key is only sent to hosts that are confirmed to be running LM Studio.
 */
'use strict';

/* ───────────────────────────────────────────────
 *  MODEL NORMALIZATION
 * ─────────────────────────────────────────────── */
function normalizeLoadedModels(payload) {
    var data = (payload && Array.isArray(payload.data)) ? payload.data : [];
    return data
        .filter(function (item) { return (item && (item.state || '').toLowerCase() === 'loaded'); })
        .filter(function (item) {
            var t = String(item && item.type || '').toLowerCase();
            return t === 'llm' || t === 'vlm';
        })
        .map(function (item) { return String(item && (item.id || item.name || item.model) || '').trim(); })
        .filter(Boolean);
}

/* ───────────────────────────────────────────────
 *  HOST PROBING (SAFE — fixes M1)
 *  First probes WITHOUT auth to confirm it's an LM Studio server,
 *  then sends authenticated request only to confirmed servers.
 * ─────────────────────────────────────────────── */
function probeHost(ip) {
    var base = 'http://' + ip + ':' + AppConfig.SCAN_PORT;
    if (!Security.isSafeApiBase(base)) return Promise.resolve(null);

    // SECURITY FIX (M1): First, try an unauthenticated probe
    // to confirm this is actually an LM Studio server.
    // Only send auth headers after confirming the host is valid.
    return Security.fetchJsonWithTimeout(base + AppConfig.MODEL_LIST_ENDPOINT, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'omit',
        cache: 'no-store'
    }, AppConfig.SCAN_TIMEOUT_MS)
    .then(function (payload) {
        // Unauthenticated probe succeeded - this is likely LM Studio
        var loaded = normalizeLoadedModels(payload);
        if (loaded.length) {
            return { base: base, models: loaded };
        }
        // Server responded but no loaded models in unauthenticated response.
        // Try with auth in case auth is required to list models.
        return Security.fetchJsonWithTimeout(base + AppConfig.MODEL_LIST_ENDPOINT, {
            method: 'GET',
            headers: Security.getAuthHeaders(),
            credentials: 'omit',
            cache: 'no-store'
        }, AppConfig.SCAN_TIMEOUT_MS)
        .then(function (authPayload) {
            var authLoaded = normalizeLoadedModels(authPayload);
            if (authLoaded.length) {
                return { base: base, models: authLoaded };
            }
            return null;
        })
        .catch(function () { return null; });
    })
    .catch(function () {
        // Unreachable — skip
        return null;
    });
}

/* ───────────────────────────────────────────────
 *  NETWORK DISCOVERY (Brute-force subnet scan)
 * ─────────────────────────────────────────────── */
function bruteForceDiscoverModels() {
    var discoverBtn = document.getElementById('discoverBtn');
    var modelCount = document.getElementById('modelCount');

    // Rate limiting check (fixes H4)
    if (!Security.checkRateLimit('network_scan', AppConfig.RATE_LIMIT_SCAN_REQUESTS, AppConfig.RATE_LIMIT_SCAN_WINDOW_MS)) {
        modelCount.textContent = 'Please wait before scanning again...';
        return Promise.resolve();
    }

    discoverBtn.disabled = true;
    modelCount.textContent = '🔍 Scanning network for LM Studio...';

    // Fast path: try saved base URL first
    var savedBase = Security.normalizeBaseUrl(Security.SafeStorage.get('lmstudio_base_url', ''));

    return _trySavedBase(savedBase)
        .then(function (result) {
            if (result) return _applyDiscoveryResult(result, discoverBtn, modelCount);
            // Try localhost
            return _tryLocalhost();
        })
        .then(function (result) {
            if (result && result.models) return _applyDiscoveryResult(result, discoverBtn, modelCount);
            if (result === true) return; // Already applied from saved base
            // Brute force scan subnet
            return _scanSubnet(modelCount)
                .then(function (scanResult) {
                    if (scanResult) {
                        return _applyDiscoveryResult(scanResult, discoverBtn, modelCount);
                    }
                    // Nothing found
                    AppState.models = [];
                    AppState.selectedModel = '';
                    saveModelSelection();
                    renderModelSelect();
                    updateHeader();
                    modelCount.textContent = 'No running models found on network';
                });
        })
        .catch(function (err) {
            console.warn('[Network] Discovery error:', err.message);
            modelCount.textContent = 'Discovery failed — check connection';
        })
        .then(function () {
            discoverBtn.disabled = false;
        });
}

function _trySavedBase(savedBase) {
    if (!savedBase || !Security.isSafeApiBase(savedBase)) return Promise.resolve(null);
    return Security.fetchJsonWithTimeout(savedBase + AppConfig.MODEL_LIST_ENDPOINT, {
        method: 'GET',
        headers: Security.getAuthHeaders(),
        credentials: 'omit',
        cache: 'no-store'
    }, 3000)
    .then(function (payload) {
        var loaded = normalizeLoadedModels(payload);
        if (loaded.length) return { base: savedBase, models: loaded };
        return null;
    })
    .catch(function () { return null; });
}

function _tryLocalhost() {
    var localhostBase = 'http://127.0.0.1:1234';
    return Security.fetchJsonWithTimeout(localhostBase + AppConfig.MODEL_LIST_ENDPOINT, {
        method: 'GET',
        headers: Security.getAuthHeaders(),
        credentials: 'omit',
        cache: 'no-store'
    }, 2000)
    .then(function (payload) {
        var loaded = normalizeLoadedModels(payload);
        if (loaded.length) return { base: localhostBase, models: loaded };
        return null;
    })
    .catch(function () { return null; });
}

function _scanSubnet(modelCount) {
    var foundResult = null;
    var batchStart = 1;

    function nextBatch() {
        if (batchStart > 254 || foundResult) return Promise.resolve(foundResult);
        var batchEnd = Math.min(batchStart + AppConfig.SCAN_BATCH_SIZE - 1, 254);
        modelCount.textContent = '🔍 Scanning ' + AppConfig.SCAN_SUBNET + '.' + batchStart + '-' + batchEnd + '...';

        var probes = [];
        for (var i = batchStart; i <= batchEnd; i++) {
            probes.push(probeHost(AppConfig.SCAN_SUBNET + '.' + i));
        }

        return Promise.all(probes).then(function (results) {
            for (var j = 0; j < results.length; j++) {
                if (results[j] && results[j].models && results[j].models.length) {
                    foundResult = results[j];
                    break;
                }
            }
            batchStart += AppConfig.SCAN_BATCH_SIZE;
            return nextBatch();
        });
    }

    return nextBatch();
}

function _applyDiscoveryResult(result, discoverBtn, modelCount) {
    AppState.currentBaseUrl = result.base;
    saveBaseUrl();
    AppState.models = result.models;
    if (AppState.models.indexOf(AppState.selectedModel) === -1) {
        AppState.selectedModel = AppState.models[0] || '';
    }
    saveModelSelection();
    renderModelSelect();
    updateHeader();
    modelCount.textContent = AppState.models.length +
        ' running model' + (AppState.models.length === 1 ? '' : 's') +
        ' found at ' + result.base;
    return true;
}

// Public alias
var discoverModels = bruteForceDiscoverModels;

/* ───────────────────────────────────────────────
 *  STREAMING CHAT COMPLETION (with size guard)
 * ─────────────────────────────────────────────── */
function streamChatCompletion(body, signal, onDelta) {
    var endpointAttempts = AppConfig.CHAT_ENDPOINTS.map(function (ep) {
        return AppState.currentBaseUrl + ep;
    });
    var lastError = null;
    var attemptIndex = 0;

    function tryNextEndpoint() {
        if (attemptIndex >= endpointAttempts.length) {
            return Promise.reject(lastError || new Error('Request failed'));
        }

        var url = endpointAttempts[attemptIndex++];

        return fetch(url, {
            method: 'POST',
            headers: Security.getAuthHeaders(),
            credentials: 'omit',
            cache: 'no-store',
            body: JSON.stringify(body),
            signal: signal
        })
        .then(function (response) {
            if (!response.ok) {
                return response.text().catch(function () { return ''; }).then(function (text) {
                    throw new Error('HTTP ' + response.status + (text ? ': ' + text.slice(0, 240) : ''));
                });
            }

            var contentType = (response.headers.get('content-type') || '').toLowerCase();
            if (!response.body || contentType.indexOf('text/event-stream') === -1) {
                return readResponsePayload(response).then(function (payload) {
                    var text = extractAssistantReply(payload);
                    if (text) onDelta(text, true);
                    return { rawText: text || '' };
                });
            }

            // Stream reading
            var reader = response.body.getReader();
            var decoder = new TextDecoder();
            var buffer = '';
            var rawText = '';
            var finalUsage = null;
            var finalReason = null;

            function readChunk() {
                return reader.read().then(function (result) {
                    if (result.done) return { rawText: rawText, usage: finalUsage, finishReason: finalReason };

                    buffer += decoder.decode(result.value, { stream: true });
                    var lines = buffer.split(/\r?\n/);
                    buffer = lines.pop() || '';

                    for (var i = 0; i < lines.length; i++) {
                        var trimmed = lines[i].trim();
                        if (trimmed.indexOf('data:') !== 0) continue;
                        var payload = trimmed.slice(5).trim();
                        if (!payload || payload === '[DONE]') continue;

                        var chunk = '';
                        try {
                            var obj = Security.safeJsonParse(payload);
                            if (obj.usage) finalUsage = obj.usage;
                            if (obj.choices && obj.choices[0] && obj.choices[0].finish_reason) {
                                finalReason = obj.choices[0].finish_reason;
                            }
                            chunk =
                                (obj.choices && obj.choices[0] && obj.choices[0].delta && obj.choices[0].delta.content != null)
                                    ? obj.choices[0].delta.content
                                    : (obj.choices && obj.choices[0] && obj.choices[0].message && obj.choices[0].message.content != null)
                                        ? obj.choices[0].message.content
                                        : (obj.choices && obj.choices[0] && obj.choices[0].text != null)
                                            ? obj.choices[0].text
                                            : (obj.content != null)
                                                ? obj.content
                                                : '';
                            if (Array.isArray(chunk)) {
                                chunk = chunk.map(function (part) {
                                    return (part && (part.text != null ? part.text : (part.content != null ? part.content : ''))) || '';
                                }).join('');
                            }
                        } catch (_e) {
                            chunk = '';
                        }

                        if (typeof chunk === 'string' && chunk) {
                            rawText += chunk;
                            // No artificial size limit — let the model complete
                            // its full response naturally (EOS / stop token).
                            onDelta(rawText, false);
                        }
                    }

                    return readChunk();
                });
            }

            return readChunk();
        })
        .catch(function (err) {
            lastError = err;
            if (err && err.name === 'AbortError') throw err;
            return tryNextEndpoint();
        });
    }

    return tryNextEndpoint();
}

function buildThinkingPrompt() {
    return {
        role: 'system',
        content: 'Thinking mode is enabled. When useful, include a brief reasoning preview inside <think>...</think> and place the final answer outside those tags. Keep the final answer clean and concise.'
    };
}
