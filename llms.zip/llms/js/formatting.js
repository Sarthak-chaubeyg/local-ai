/**
 * Formatting Module — HTML escaping, markdown formatting, code highlighting.
 * All rendering of user/assistant text goes through this module.
 *
 * Uses Security.escapeHtml / Security.escapeAttr for safe output.
 */
'use strict';

/* ───────────────────────────────────────────────
 *  MESSAGE NORMALIZATION
 * ─────────────────────────────────────────────── */
function normalizeMessagePayload(message) {
    if (message && typeof message === 'object') {
        return {
            role: message.role || '',
            content: String(message.content != null ? message.content : (message.text != null ? message.text : '')),
            thinking: String(message.thinking != null ? message.thinking : (message.analysis != null ? message.analysis : '')),
            thinkingDuration: Number(message.thinkingDuration || message.duration || 0) || 0,
            model: String(message.model != null ? message.model : ''),
            usage: message.usage || null,
            finishReason: String(message.finishReason || ''),
            totalDuration: Number(message.totalDuration || 0) || 0
        };
    }
    return {
        role: '',
        content: String(message != null ? message : ''),
        thinking: '',
        thinkingDuration: 0,
        model: '',
        usage: null,
        finishReason: '',
        totalDuration: 0
    };
}

function normalizeAssistantText(rawText) {
    return String(rawText || '')
        .replace(/\r\n/g, '\n')
        .replace(/^\uFEFF/, '')
        .replace(/^\s+/, '');
}

function extractThinkingFromReply(rawText) {
    var text = normalizeAssistantText(rawText);
    if (!text) return { thinking: '', finalText: '' };

    var explicitPatterns = [
        /\<think\>([\s\S]*?)\<\/think\>/i,
        /\<analysis\>([\s\S]*?)\<\/analysis\>/i,
        /\<reasoning\>([\s\S]*?)\<\/reasoning\>/i
    ];

    for (var i = 0; i < explicitPatterns.length; i++) {
        var match = text.match(explicitPatterns[i]);
        if (match) {
            var thinking = String(match[1] || '').trim();
            var finalText = text.replace(explicitPatterns[i], '').trim();
            return { thinking: thinking, finalText: finalText };
        }
    }

    if (/^thinking process:/i.test(text) || /^thought for\s+\d/i.test(text)) {
        var parts = text.split(/\n\n+/);
        if (parts.length > 1) {
            var thinkPart = parts.shift().trim();
            var rest = parts.join('\n\n').trim();
            return { thinking: thinkPart, finalText: rest };
        }
    }

    return { thinking: '', finalText: text };
}

/* ───────────────────────────────────────────────
 *  INLINE MARKDOWN FORMATTING
 * ─────────────────────────────────────────────── */

/**
 * formatText: Renders inline markdown (bold, inline code, headers, line breaks).
 * Does NOT handle fenced code blocks — use formatAssistantBody for that.
 */
function formatText(rawText) {
    var text = Security.escapeHtml(rawText || '');
    text = text.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');
    text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    text = text.replace(/\*(.+?)\*/g, '<strong>$1</strong>');
    text = text.replace(/(^|\n)\#\s(.+?)(?=\n|$)/g, '$1<span class="lead">$2</span>');
    text = text.replace(/\n/g, '<br>');
    return text;
}

/* ───────────────────────────────────────────────
 *  CODE BLOCK PARSING
 * ─────────────────────────────────────────────── */

/**
 * parseSegments: Splits raw text into text and code segments.
 * Handles ``` fenced code blocks.
 */
function parseSegments(raw) {
    var segments = [];
    var source = String(raw || '');
    var re = /[ \t]*```(?:([\w-]+)[ \t]*)?\r?\n([\s\S]*?)```/g;
    var last = 0;
    var m;
    while ((m = re.exec(source))) {
        if (m.index > last) segments.push({ type: 'text', content: source.slice(last, m.index) });
        segments.push({ type: 'code', lang: (m[1] || '').trim().toLowerCase(), content: m[2] });
        last = re.lastIndex;
    }
    if (last < source.length) segments.push({ type: 'text', content: source.slice(last) });
    return segments.filter(function (seg) { return seg.content !== ''; });
}

/* ───────────────────────────────────────────────
 *  SYNTAX HIGHLIGHTING
 * ─────────────────────────────────────────────── */
function highlightCode(code, lang) {
    var html = Security.escapeHtml(code);
    var l = (lang || '').toLowerCase();

    if (l === 'html' || l === 'xml' || l === 'svg') {
        html = html.replace(/(&#060;!--[\s\S]*?--&#062;)/g, '<span class="tok-comment">$1</span>');
        html = html.replace(/(&lt;!--[\s\S]*?--&gt;)/g, '<span class="tok-comment">$1</span>');
        html = html.replace(/\b(class|id|href|src|style|alt|title|type|name|value|for|role|data-[a-zA-Z0-9-]*|aria-[a-zA-Z0-9-]*)(=)/g, ' <span class="tok-attr">$1</span>$2');
        html = html.replace(/(&quot;.*?&quot;|&#039;.*?&#039;)/g, '<span class="tok-string">$1</span>');
        return html;
    }

    if (l === 'css') {
        html = html.replace(/\/\*[\s\S]*?\*\//g, '<span class="tok-comment">$&</span>');
        html = html.replace(/(&quot;.*?&quot;|&#039;.*?&#039;)/g, '<span class="tok-string">$1</span>');
        html = html.replace(/([\w-]+)(\s*:)/g, '<span class="tok-prop">$1</span>$2');
        html = html.replace(/\b([0-9]+(?:\.[0-9]+)?)(px|rem|em|vh|vw|%|s|ms)?\b/g, '<span class="tok-number">$1$2</span>');
        return html;
    }

    html = html.replace(/\/\/.*$/gm, '<span class="tok-comment">$&</span>');
    html = html.replace(/\/\*[\s\S]*?\*\//g, '<span class="tok-comment">$&</span>');
    html = html.replace(/(&quot;.*?&quot;|&#039;.*?&#039;|`.*?`)/g, '<span class="tok-string">$1</span>');
    html = html.replace(/\b(\d+(?:\.\d+)?)\b/g, '<span class="tok-number">$1</span>');
    html = html.replace(/\b(const|let|var|function|return|if|else|for|while|switch|case|break|continue|class|new|try|catch|finally|async|await|throw|import|from|export|default|extends|super|this|true|false|null|undefined)\b/g, '<span class="tok-keyword">$1</span>');
    return html;
}

/* ───────────────────────────────────────────────
 *  ASSISTANT BODY RENDERING (code blocks)
 * ─────────────────────────────────────────────── */

/**
 * formatAssistantBody: Handles BOTH text and code blocks properly.
 * Uses the copy registry instead of data-code attributes for safer copy.
 */
function formatAssistantBody(rawText) {
    var segments = parseSegments(rawText);
    if (!segments.length) return '<div class="message-text"></div>';
    return segments.map(function (seg) {
        if (seg.type === 'text') return '<div class="message-text">' + formatText(seg.content) + '</div>';
        var langLabel = seg.lang ? seg.lang : 'code';
        var highlighted = highlightCode(seg.content, seg.lang);
        // Register code in copy registry instead of using data-code attribute (fixes M5)
        var copyId = AppState._copyRegistry.length;
        AppState._copyRegistry.push(seg.content);
        return '<div class="code-block" data-copy-id="' + copyId + '">' +
            '<div class="code-head">' +
            '<span class="code-lang">' + Security.escapeHtml(langLabel) + '</span>' +
            '<button class="code-copy-btn" title="Copy code" data-action="copy-code" data-copy-id="' + copyId + '">' +
            '<i class="ri-file-copy-line"></i> Copy</button>' +
            '</div>' +
            '<pre><code class="code-content">' + highlighted + '</code></pre>' +
            '</div>';
    }).join('');
}

/**
 * formatLiveStreamingBody: Used during live streaming to show content.
 */
function formatLiveStreamingBody(rawText) {
    var text = String(rawText || '');
    var hasCompleteCodeBlock = /```[\w-]*\s*\r?\n[\s\S]*?```/.test(text);
    var hasIncompleteCodeFence = /```[\w-]*\s*\r?\n[^`]*$/.test(text);

    if (hasCompleteCodeBlock) {
        if (hasIncompleteCodeFence) {
            var segments = parseSegments(text);
            var result = '';
            for (var i = 0; i < segments.length; i++) {
                var seg = segments[i];
                if (seg.type === 'text') {
                    var incompleteFenceMatch = seg.content.match(/```[\w-]*\s*\r?\n([\s\S]*)$/);
                    if (incompleteFenceMatch) {
                        var beforeFence = seg.content.slice(0, incompleteFenceMatch.index);
                        var streamingCode = incompleteFenceMatch[1] || '';
                        if (beforeFence.trim()) {
                            result += '<div class="message-text">' + formatText(beforeFence) + '</div>';
                        }
                        var langMatch = seg.content.match(/```([\w-]+)/);
                        var streamLang = langMatch ? langMatch[1] : 'code';
                        result += '<div class="code-block">' +
                            '<div class="code-head">' +
                            '<span class="code-lang">' + Security.escapeHtml(streamLang) + '</span>' +
                            '<span class="streaming-indicator">streaming…</span>' +
                            '</div>' +
                            '<pre><code class="code-content">' + highlightCode(streamingCode, streamLang) + '</code></pre>' +
                            '</div>';
                    } else {
                        result += '<div class="message-text">' + formatText(seg.content) + '</div>';
                    }
                } else {
                    var langLabel2 = seg.lang ? seg.lang : 'code';
                    var highlighted2 = highlightCode(seg.content, seg.lang);
                    var copyId2 = AppState._copyRegistry.length;
                    AppState._copyRegistry.push(seg.content);
                    result += '<div class="code-block" data-copy-id="' + copyId2 + '">' +
                        '<div class="code-head">' +
                        '<span class="code-lang">' + Security.escapeHtml(langLabel2) + '</span>' +
                        '<button class="code-copy-btn" title="Copy code" data-action="copy-code" data-copy-id="' + copyId2 + '">' +
                        '<i class="ri-file-copy-line"></i> Copy</button>' +
                        '</div>' +
                        '<pre><code class="code-content">' + highlighted2 + '</code></pre>' +
                        '</div>';
                }
            }
            return result;
        }
        return formatAssistantBody(text);
    }

    if (hasIncompleteCodeFence) {
        var fenceMatch = text.match(/([\s\S]*?)```([\w-]*)\s*\r?\n([\s\S]*)$/);
        if (fenceMatch) {
            var beforeFence2 = fenceMatch[1] || '';
            var streamLang2 = fenceMatch[2] || 'code';
            var streamingCode2 = fenceMatch[3] || '';
            var result2 = '';
            if (beforeFence2.trim()) {
                result2 += '<div class="message-text">' + formatText(beforeFence2) + '</div>';
            }
            result2 += '<div class="code-block">' +
                '<div class="code-head">' +
                '<span class="code-lang">' + Security.escapeHtml(streamLang2) + '</span>' +
                '<span class="streaming-indicator">streaming…</span>' +
                '</div>' +
                '<pre><code class="code-content">' + highlightCode(streamingCode2, streamLang2) + '</code></pre>' +
                '</div>';
            return result2;
        }
    }

    return '<div class="message-text">' + formatText(text) + '</div>';
}

/* ───────────────────────────────────────────────
 *  RESPONSE PARSING
 * ─────────────────────────────────────────────── */
function extractAssistantReply(responseData) {
    var candidates = [
        responseData && responseData.choices && responseData.choices[0] && responseData.choices[0].message && responseData.choices[0].message.content,
        responseData && responseData.choices && responseData.choices[0] && responseData.choices[0].delta && responseData.choices[0].delta.content,
        responseData && responseData.choices && responseData.choices[0] && responseData.choices[0].text,
        responseData && responseData.message && responseData.message.content,
        responseData && responseData.content,
        responseData && responseData.response,
        responseData && responseData.output_text,
        responseData && responseData.text,
        responseData && responseData.reply,
        responseData && responseData.completion
    ];

    for (var i = 0; i < candidates.length; i++) {
        var item = candidates[i];
        if (Array.isArray(item)) {
            var joined = item.map(function (part) {
                if (typeof part === 'string') return part;
                return (part && (part.text != null ? part.text : (part.content != null ? part.content : ''))) || '';
            }).join('');
            if (joined.trim()) return normalizeAssistantText(joined);
        } else if (typeof item === 'string' && item.trim()) {
            return normalizeAssistantText(item);
        }
    }

    if (typeof responseData === 'string' && responseData.trim()) {
        return normalizeAssistantText(responseData);
    }

    return '';
}

function parseStreamedAssistantReply(rawText) {
    var lines = String(rawText || '').split(/\r?\n/);
    var output = '';
    for (var i = 0; i < lines.length; i++) {
        var trimmed = lines[i].trim();
        if (trimmed.indexOf('data:') !== 0) continue;
        var payload = trimmed.slice(5).trim();
        if (!payload || payload === '[DONE]') continue;
        try {
            var obj = Security.safeJsonParse(payload);
            var chunk =
                (obj && obj.choices && obj.choices[0] && obj.choices[0].delta && obj.choices[0].delta.content != null)
                    ? obj.choices[0].delta.content
                    : (obj && obj.choices && obj.choices[0] && obj.choices[0].message && obj.choices[0].message.content != null)
                        ? obj.choices[0].message.content
                        : (obj && obj.choices && obj.choices[0] && obj.choices[0].text != null)
                            ? obj.choices[0].text
                            : (obj && obj.content != null)
                                ? obj.content
                                : '';
            if (typeof chunk === 'string') output += chunk;
            else if (Array.isArray(chunk)) {
                output += chunk.map(function (part) {
                    return (part && (part.text != null ? part.text : (part.content != null ? part.content : ''))) || '';
                }).join('');
            }
        } catch (_e) { }
    }
    return normalizeAssistantText(output);
}

function readResponsePayload(response) {
    return response.text().then(function (raw) {
        if (!raw) return {};
        try {
            return Security.safeJsonParse(raw);
        } catch (_e) {
            var streamed = parseStreamedAssistantReply(raw);
            return streamed ? { content: streamed } : { content: raw };
        }
    });
}

/* ───────────────────────────────────────────────
 *  SMART TITLE
 * ─────────────────────────────────────────────── */
function makeSmartTitle(firstMessage) {
    var text = (firstMessage || '').trim();
    if (!text) return 'New Chat';
    var normalized = text.toLowerCase();
    if (/^(hi|hello|hey|good morning|good afternoon|good evening)\b/.test(normalized)) return 'Greeting by User';
    if (normalized.indexOf('help') !== -1) return 'Help Request';
    if (normalized.indexOf('idea') !== -1) return 'Idea Discussion';
    if (normalized.indexOf('code') !== -1 || normalized.indexOf('website') !== -1 || normalized.indexOf('html') !== -1) return 'Coding Chat';
    return Security.validateChatTitle(text.slice(0, 28).replace(/\s+/g, ' '));
}
