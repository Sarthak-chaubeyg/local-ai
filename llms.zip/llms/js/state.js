/**
 * State Module — Centralized application state with safe persistence.
 * All mutable state lives here. Other modules read/write via AppState.
 *
 * Uses Security.SafeStorage for quota-aware, error-safe localStorage access.
 */
'use strict';

var AppState = {
    /* Chat data */
    chats: [],
    currentChatIndex: null,

    /* Model data */
    models: [],
    selectedModel: '',

    /* Generation state */
    isGenerating: false,
    currentAbortController: null,
    activePlaceholder: null,
    activePlaceholderChatIndex: null,
    generationToken: 0,

    /* Thinking mode */
    thinkingEnabled: false,
    thinkingSupported: false,

    /* Live streaming */
    activeLiveAssistant: null,

    /* Network */
    currentBaseUrl: '',

    /* Model Manager */
    allDownloadedModels: [],
    mmBusy: new Set(),

    /* Copy registry — avoids inline content in HTML attributes */
    _copyRegistry: [],

    /* Toast timer */
    _toastTimer: null
};

/* ───────────────────────────────────────────────
 *  PERSISTENCE HELPERS (with SafeStorage)
 * ─────────────────────────────────────────────── */
function saveChats() {
    // Enforce max chats limit
    if (AppState.chats.length > AppConfig.MAX_CHATS) {
        AppState.chats = AppState.chats.slice(-AppConfig.MAX_CHATS);
        if (AppState.currentChatIndex !== null) {
            AppState.currentChatIndex = Math.min(AppState.currentChatIndex, AppState.chats.length - 1);
        }
    }
    // Enforce max messages per chat
    for (var i = 0; i < AppState.chats.length; i++) {
        var chat = AppState.chats[i];
        if (chat.messages && chat.messages.length > AppConfig.MAX_MESSAGES_PER_CHAT) {
            chat.messages = chat.messages.slice(-AppConfig.MAX_MESSAGES_PER_CHAT);
        }
    }
    Security.SafeStorage.set("all_chats", AppState.chats);
}

function saveModelSelection() {
    Security.SafeStorage.set("selected_model", AppState.selectedModel || "");
}

function saveBaseUrl() {
    Security.SafeStorage.set("lmstudio_base_url", Security.normalizeBaseUrl(AppState.currentBaseUrl));
}

/* ───────────────────────────────────────────────
 *  LOAD STATE FROM STORAGE
 * ─────────────────────────────────────────────── */
function loadPersistedState() {
    // Load chats — with validation
    var rawChats = Security.SafeStorage.getJSON("all_chats", []);
    if (Array.isArray(rawChats)) {
        AppState.chats = rawChats.filter(function (chat) {
            return chat && typeof chat === 'object' && Array.isArray(chat.messages);
        }).map(function (chat) {
            // Sanitize each chat's title
            return {
                title: Security.validateChatTitle(chat.title || 'Untitled Chat'),
                messages: chat.messages.slice(0, AppConfig.MAX_MESSAGES_PER_CHAT).map(function (msg) {
                    if (!msg || typeof msg !== 'object') return null;
                    return {
                        role: String(msg.role || ''),
                        content: String(msg.content || ''),
                        thinking: String(msg.thinking || ''),
                        thinkingDuration: Number(msg.thinkingDuration || 0) || 0,
                        model: String(msg.model || ''),
                        usage: msg.usage || null,
                        finishReason: String(msg.finishReason || ''),
                        totalDuration: Number(msg.totalDuration || 0) || 0
                    };
                }).filter(Boolean)
            };
        });
    } else {
        AppState.chats = [];
    }

    // Load selected model
    AppState.selectedModel = Security.SafeStorage.get("selected_model", "");

    // Load base URL with validation
    var savedUrl = Security.SafeStorage.get("lmstudio_base_url", "http://192.168.1.2:1234");
    var normalizedUrl = Security.normalizeBaseUrl(savedUrl);
    if (Security.isSafeApiBase(normalizedUrl)) {
        AppState.currentBaseUrl = normalizedUrl;
    } else {
        AppState.currentBaseUrl = "http://192.168.1.2:1234";
    }
}
