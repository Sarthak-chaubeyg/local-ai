/* ╔═══════════════════════════════════════════════════════════╗
 * ║          CONFIGURATION — CHANGE PER DEVICE               ║
 * ╠═══════════════════════════════════════════════════════════╣
 * ║                                                           ║
 * ║  ✅ MUST CHANGE:                                          ║
 * ║  1. LMSTUDIO_API_KEY — Each LM Studio instance has its    ║
 * ║     own API key. Go to LM Studio → Developer tab →        ║
 * ║     copy the API key and paste it below.                   ║
 * ║                                                           ║
 * ║  🔄 AUTO-DETECTED (no change needed):                     ║
 * ║  - The IP address is auto-scanned on the subnet.          ║
 * ║  - The loaded model is auto-discovered.                   ║
 * ║                                                           ║
 * ║  ⚙️ OPTIONAL (only if your network is different):         ║
 * ║  - SCAN_SUBNET — Change if your WiFi uses a different     ║
 * ║    subnet (e.g. "192.168.0" or "10.0.0")                  ║
 * ║  - SCAN_PORT — Change if LM Studio runs on a different    ║
 * ║    port (default is 1234)                                  ║
 * ║                                                           ║
 * ║  🔒 SECURITY NOTE:                                        ║
 * ║  This file is .gitignored. Never commit it to version     ║
 * ║  control. Rotate your API key if it was ever exposed.     ║
 * ║                                                           ║
 * ╚═══════════════════════════════════════════════════════════╝ */
'use strict';

var AppConfig = Object.freeze({
    /* ⬇️⬇️⬇️ CHANGE THIS — paste your LM Studio API key here ⬇️⬇️⬇️ */
    LMSTUDIO_API_KEY: "sk-lm-yfmMehka:i7rHDXZVo7orXbNhOyKt",
    /* ⬆️⬆️⬆️ Get this from: LM Studio → Developer tab → API Key ⬆️⬆️⬆️ */

    /* API Endpoints */
    CHAT_ENDPOINTS: Object.freeze(["/v1/chat/completions", "/api/v0/chat/completions"]),
    MODEL_LIST_ENDPOINT: "/api/v0/models",
    MODEL_LIST_V1_ENDPOINT: "/api/v1/models",
    MODEL_LOAD_ENDPOINT: "/api/v1/models/load",
    MODEL_UNLOAD_ENDPOINT: "/api/v1/models/unload",

    /* Auth & Network */
    REQUIRE_API_KEY: true,
    ALLOWED_LOCALHOSTS: Object.freeze(["localhost", "127.0.0.1", "::1"]),
    ALLOW_PRIVATE_NETWORK: true,

    /* Limits & Guards */
    MAX_RESPONSE_CHARS: 120000,
    MAX_CONTEXT_MESSAGES: 24,
    MAX_INPUT_LENGTH: 32000,        // Max user message length in chars
    MAX_CHAT_TITLE_LENGTH: 100,     // Max rename title length
    MAX_CHATS: 500,                 // Max number of saved chats
    MAX_MESSAGES_PER_CHAT: 2000,    // Max messages per chat
    MAX_STREAMING_SIZE: 5 * 1024 * 1024,   // 5 MB max streaming response
    MAX_LOCALSTORAGE_MB: 4.5,              // Leave headroom from 5MB limit
    MAX_UPLOAD_SIZE_MB: 30,                // 30 MB per chat file upload limit

    /* Network Scanning */
    SCAN_SUBNET: "192.168.1",
    SCAN_PORT: 1234,
    SCAN_TIMEOUT_MS: 1500,
    SCAN_BATCH_SIZE: 20,

    /* Rate Limiting (token‑bucket) */
    RATE_LIMIT_SEND_REQUESTS: 5,      // Max sends per window
    RATE_LIMIT_SEND_WINDOW_MS: 10000, // 10 second window
    RATE_LIMIT_SCAN_REQUESTS: 2,      // Max full scans per window
    RATE_LIMIT_SCAN_WINDOW_MS: 30000  // 30 second window
});
